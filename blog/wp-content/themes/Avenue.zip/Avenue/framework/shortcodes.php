<?php

class PyreThemeFrameworkShortcodes {
	
	public function __construct()
	{
	}
	
}

$shortcodes = new PyreThemeFrameworkShortcodes;