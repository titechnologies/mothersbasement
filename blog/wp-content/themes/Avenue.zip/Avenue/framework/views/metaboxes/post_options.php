<div class='pyre_metabox'>
<?php
$this->select(	'featured_image',
				'Show featured image',
				array(
					'yes' => 'Yes',
					'no' => 'No',
				),
				'Show featured image on single post page'
			);
?>
</div>