<div class="pyre_metabox">
<?php
$this->select(	'overall_score',
				'Overall Score',
				array(
					'0' => '0',
					'0.5' => '0.5',
					'1' => '1',
					'1.5' => '1.5',
					'2' => '2',
					'2.5' => '2.5',
					'3' => '3',
					'3.5' => '3.5',
					'4' => '4',
					'4.5' => '4.5',
					'5' => '5'
				),
				'Choose a number between 0.5 to 5 (eg. 4.5)'
			);
			
$this->text(	'critera_1',
				'Critera 1',
				'Enter a rating Criteria (eg. Sound)'
			);
			
$this->select(	'critera_1_score',
				'Critera 1 Score',
				array(
					'0' => '0',
					'0.5' => '0.5',
					'1' => '1',
					'1.5' => '1.5',
					'2' => '2',
					'2.5' => '2.5',
					'3' => '3',
					'3.5' => '3.5',
					'4' => '4',
					'4.5' => '4.5',
					'5' => '5'
				)
			);
			
$this->text(	'critera_2',
				'Critera 2'
			);
			
$this->select(	'critera_2_score',
				'Critera 2 Score',
				array(
					'0' => '0',
					'0.5' => '0.5',
					'1' => '1',
					'1.5' => '1.5',
					'2' => '2',
					'2.5' => '2.5',
					'3' => '3',
					'3.5' => '3.5',
					'4' => '4',
					'4.5' => '4.5',
					'5' => '5'
				)
			);
			
$this->text(	'critera_3',
				'Critera 3'
			);
			
$this->select(	'critera_3_score',
				'Critera 3 Score',
				array(
					'0' => '0',
					'0.5' => '0.5',
					'1' => '1',
					'1.5' => '1.5',
					'2' => '2',
					'2.5' => '2.5',
					'3' => '3',
					'3.5' => '3.5',
					'4' => '4',
					'4.5' => '4.5',
					'5' => '5'
				)
			);
			
$this->text(	'critera_4',
				'Critera 4'
			);
			
$this->select(	'critera_4_score',
				'Critera 4 Score',
				array(
					'0' => '0',
					'0.5' => '0.5',
					'1' => '1',
					'1.5' => '1.5',
					'2' => '2',
					'2.5' => '2.5',
					'3' => '3',
					'3.5' => '3.5',
					'4' => '4',
					'4.5' => '4.5',
					'5' => '5'
				)
			);
			
$this->text(	'critera_5',
				'Critera 5'
			);
			
$this->select(	'critera_5_score',
				'Critera 5 Score',
				array(
					'0' => '0',
					'0.5' => '0.5',
					'1' => '1',
					'1.5' => '1.5',
					'2' => '2',
					'2.5' => '2.5',
					'3' => '3',
					'3.5' => '3.5',
					'4' => '4',
					'4.5' => '4.5',
					'5' => '5'
				)
			);
?>
</div>