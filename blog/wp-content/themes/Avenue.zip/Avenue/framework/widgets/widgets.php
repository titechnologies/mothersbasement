<?php
include_once('social_counter_widget.php');
include_once('tabs_widget.php');
include_once('posts_widget.php');

include_once('homepage_2col_widget.php');
include_once('homepage_1col_widget.php');
include_once('homepage_media_widget.php');

include_once('tweets-widget.php');
include_once('flickr-widget.php');
include_once('facebook-like-widget.php');

include_once('latest_reviews.php');